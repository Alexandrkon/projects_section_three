mvn versions:set -DnewVersion=1.2-SNAPSHOT
