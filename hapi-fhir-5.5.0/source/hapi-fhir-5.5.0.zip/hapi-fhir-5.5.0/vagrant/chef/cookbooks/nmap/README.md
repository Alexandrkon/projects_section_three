# nmap cookbook

# Requirements
Chef 10.16.2 or above

# Usage
simply include 'recipe[nmap]' in a node's run_list

# Attributes

# Recipes
default.rb : installs the nmap package

# Author

Author:: Sean OMeara (<someara@opscode.com>)
