#
# Cookbook Name:: nmap
# Recipe:: default
#
# Author :: Sean OMeara <someara@opscode.com>
# Copyright (C) 2012 Opscode
# 
# Apache2 license
#

package "nmap"
