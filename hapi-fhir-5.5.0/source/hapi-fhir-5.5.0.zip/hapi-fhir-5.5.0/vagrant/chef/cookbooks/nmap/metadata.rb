name             "nmap"
maintainer       "Sean OMeara"
maintainer_email "someara@opscode.com"
license          "Apache2"
description      "Installs/Configures nmap"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.1.0"

