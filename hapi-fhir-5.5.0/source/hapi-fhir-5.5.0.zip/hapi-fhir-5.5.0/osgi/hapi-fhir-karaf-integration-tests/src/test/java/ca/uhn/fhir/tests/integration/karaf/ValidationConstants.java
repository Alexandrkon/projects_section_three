package ca.uhn.fhir.tests.integration.karaf;

public class ValidationConstants {

	public static final boolean SCHEMATRON_ENABLED = true;

}
