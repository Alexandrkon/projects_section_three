package test;

public interface ResourceTest {
	String getResourceName();
}
