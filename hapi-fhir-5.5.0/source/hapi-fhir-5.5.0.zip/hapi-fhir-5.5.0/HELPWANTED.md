# Help Wanted

This page is a work in progress!

It serves as a place to list potential help a new volunteer could offer.

* Investigate adding support for FHIR's RDF (Turtle) encoding to HAPI

