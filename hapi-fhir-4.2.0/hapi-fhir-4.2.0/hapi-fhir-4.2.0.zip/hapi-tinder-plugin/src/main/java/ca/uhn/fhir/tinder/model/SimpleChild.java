package ca.uhn.fhir.tinder.model;

public class SimpleChild extends Child {

}
