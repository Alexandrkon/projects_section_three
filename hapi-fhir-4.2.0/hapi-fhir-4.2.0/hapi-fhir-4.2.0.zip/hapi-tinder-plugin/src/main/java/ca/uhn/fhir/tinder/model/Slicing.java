package ca.uhn.fhir.tinder.model;

public class Slicing {

	private String myDiscriminator;

	public String getDiscriminator() {
		return myDiscriminator;
	}

	public void setDiscriminator(String theDiscriminator) {
		myDiscriminator = theDiscriminator;
	}
	
}
